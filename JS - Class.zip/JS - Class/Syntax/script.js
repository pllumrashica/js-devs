// alert('this is javascript syntax external');

// comments

// single lines

// multiple lines

/* asdasfgsdf
afs
sdf
sda
fg  */


//every single row should finish with semicolon
console.log('testing semicolons');


// variables let var const
let firstName = 'Alaudini';
console.log(firstName);

// document
document.write(firstName);

// log numbers
let phoneNumber = 40;
let homeNumber = 40;

// console log description
console.log(phoneNumber, 'this is phone number');
console.log(homeNumber, 'this is home number');

// conditions
let age = 18;

if (age < 19) {
    console.log('too young');
}
else {
    console.log('too old');
}

// arrays
let subjects = ['math', 'bio', 'shqip'];
console.log(subjects[2])